"""Database schema.

    users ──< workouts ──< workout_exercises >── exercises
      └──< refresh_tokens
      └──< revoked_tokens

A `workout` is a plan (a named session, optionally scheduled for a date/time).
A `workout_exercise` is one line inside that plan: an exercise plus the sets,
reps and weight prescribed for it. Splitting them this way means the exercise
catalogue stays shared and read-only while the prescription is per-user.
"""

from __future__ import annotations

import enum
from datetime import datetime, timezone

from sqlalchemy import (
    CheckConstraint,
    Enum,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base, UTCDateTime


def utcnow() -> datetime:
    """Timezone-aware UTC now. Never use naive datetimes in the DB."""
    return datetime.now(timezone.utc)


class WorkoutStatus(str, enum.Enum):
    pending = "pending"      # created, not yet done
    completed = "completed"  # done — counts toward reports
    skipped = "skipped"      # scheduled but missed


# ---------------------------------------------------------------------------
# Users
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True, nullable=False)
    username: Mapped[str] = mapped_column(String(50), unique=True, index=True, nullable=False)
    hashed_password: Mapped[str] = mapped_column(String(255), nullable=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    workouts: Mapped[list[Workout]] = relationship(
        back_populates="user", cascade="all, delete-orphan"
    )


# ---------------------------------------------------------------------------
# Exercise catalogue (shared, populated by the seeder)
# ---------------------------------------------------------------------------
class Exercise(Base):
    __tablename__ = "exercises"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120), unique=True, index=True, nullable=False)
    description: Mapped[str] = mapped_column(Text, default="")
    category: Mapped[str] = mapped_column(String(30), index=True, nullable=False)     # strength | cardio | flexibility
    muscle_group: Mapped[str] = mapped_column(String(30), index=True, nullable=False)  # chest | back | legs | ...


# ---------------------------------------------------------------------------
# Workouts
# ---------------------------------------------------------------------------
class Workout(Base):
    __tablename__ = "workouts"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False
    )
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    comment: Mapped[str | None] = mapped_column(Text, default=None)
    scheduled_at: Mapped[datetime | None] = mapped_column(
        UTCDateTime, index=True, default=None
    )
    status: Mapped[WorkoutStatus] = mapped_column(
        Enum(WorkoutStatus, native_enum=False, length=20),
        default=WorkoutStatus.pending,
        index=True,
        nullable=False,
    )
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime, default=None)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime, default=utcnow, onupdate=utcnow
    )

    user: Mapped[User] = relationship(back_populates="workouts")
    entries: Mapped[list[WorkoutExercise]] = relationship(
        back_populates="workout",
        cascade="all, delete-orphan",
        order_by="WorkoutExercise.position",
    )

    @property
    def total_volume(self) -> float:
        return round(sum(entry.volume for entry in self.entries), 2)


class WorkoutExercise(Base):
    """One prescribed exercise inside a workout."""

    __tablename__ = "workout_exercises"
    __table_args__ = (
        CheckConstraint("sets > 0", name="ck_sets_positive"),
        CheckConstraint("reps > 0", name="ck_reps_positive"),
        CheckConstraint("weight >= 0", name="ck_weight_non_negative"),
    )

    id: Mapped[int] = mapped_column(primary_key=True)
    workout_id: Mapped[int] = mapped_column(
        ForeignKey("workouts.id", ondelete="CASCADE"), index=True, nullable=False
    )
    exercise_id: Mapped[int] = mapped_column(
        ForeignKey("exercises.id", ondelete="RESTRICT"), index=True, nullable=False
    )
    position: Mapped[int] = mapped_column(Integer, default=0)  # display order
    sets: Mapped[int] = mapped_column(Integer, nullable=False)
    reps: Mapped[int] = mapped_column(Integer, nullable=False)
    weight: Mapped[float] = mapped_column(Float, default=0.0)  # kg; 0 for bodyweight/cardio
    notes: Mapped[str | None] = mapped_column(Text, default=None)

    workout: Mapped[Workout] = relationship(back_populates="entries")
    exercise: Mapped[Exercise] = relationship(lazy="joined")

    @property
    def volume(self) -> float:
        """sets x reps x weight — the standard training-volume figure."""
        return self.sets * self.reps * (self.weight or 0.0)


# ---------------------------------------------------------------------------
# Token bookkeeping (so logout actually invalidates)
# ---------------------------------------------------------------------------
class RefreshToken(Base):
    """Stored refresh tokens. Rotated on use, revoked on logout."""

    __tablename__ = "refresh_tokens"
    __table_args__ = (UniqueConstraint("jti", name="uq_refresh_jti"),)

    id: Mapped[int] = mapped_column(primary_key=True)
    jti: Mapped[str] = mapped_column(String(64), index=True, nullable=False)
    user_id: Mapped[int] = mapped_column(
        ForeignKey("users.id", ondelete="CASCADE"), index=True, nullable=False
    )
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime, nullable=False)
    revoked_at: Mapped[datetime | None] = mapped_column(UTCDateTime, default=None)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)

    @property
    def is_active(self) -> bool:
        expires = self.expires_at
        if expires.tzinfo is None:  # SQLite round-trips naive datetimes
            expires = expires.replace(tzinfo=timezone.utc)
        return self.revoked_at is None and expires > utcnow()


class RevokedAccessToken(Base):
    """Denylist for access tokens killed before their natural expiry (logout).

    Entries are only needed until the token would have expired anyway, so this
    table stays small — purge_expired() clears the dead rows.
    """

    __tablename__ = "revoked_access_tokens"

    id: Mapped[int] = mapped_column(primary_key=True)
    jti: Mapped[str] = mapped_column(String(64), unique=True, index=True, nullable=False)
    expires_at: Mapped[datetime] = mapped_column(UTCDateTime, nullable=False)
    created_at: Mapped[datetime] = mapped_column(UTCDateTime, default=utcnow)
