"""Exercise data seeder.

Run standalone:      python -m app.seed
Runs automatically:  on app startup, if the exercises table is empty.

Idempotent — matches on the unique exercise name, inserts what's missing and
updates descriptions that have changed, so re-running is always safe.
"""

from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import SessionLocal
from app.models import Exercise

# (name, category, muscle_group, description)
EXERCISES: list[tuple[str, str, str, str]] = [
    # --- Chest ---------------------------------------------------------
    ("Barbell Bench Press", "strength", "chest", "Flat barbell press; the benchmark horizontal push."),
    ("Incline Dumbbell Press", "strength", "chest", "Press on a 30-45 degree bench to bias the upper chest."),
    ("Push-Up", "strength", "chest", "Bodyweight horizontal press; scale by elevating hands or feet."),
    ("Cable Chest Fly", "strength", "chest", "Isolation fly keeping constant tension through the arc."),
    ("Chest Dip", "strength", "chest", "Lean forward on parallel bars to load the lower chest."),
    # --- Back ----------------------------------------------------------
    ("Pull-Up", "strength", "back", "Overhand vertical pull from a dead hang."),
    ("Chin-Up", "strength", "back", "Underhand vertical pull; more biceps than a pull-up."),
    ("Barbell Row", "strength", "back", "Bent-over horizontal pull for mid-back thickness."),
    ("Lat Pulldown", "strength", "back", "Cable vertical pull; the scalable pull-up substitute."),
    ("Seated Cable Row", "strength", "back", "Horizontal cable pull with a neutral grip."),
    ("Face Pull", "strength", "back", "Rope pull to the face for rear delts and scapular health."),
    # --- Legs ----------------------------------------------------------
    ("Back Squat", "strength", "legs", "Barbell on the upper back; the primary knee-dominant lift."),
    ("Front Squat", "strength", "legs", "Barbell racked on the shoulders; more upright, more quads."),
    ("Conventional Deadlift", "strength", "legs", "Full-body hip hinge pulling from the floor."),
    ("Romanian Deadlift", "strength", "legs", "Hinge with soft knees to load the hamstrings."),
    ("Bulgarian Split Squat", "strength", "legs", "Rear-foot-elevated single-leg squat."),
    ("Walking Lunge", "strength", "legs", "Alternating forward lunges over distance."),
    ("Leg Press", "strength", "legs", "Machine press; heavy quad work with low stability demand."),
    ("Standing Calf Raise", "strength", "legs", "Loaded plantarflexion through a full stretch."),
    ("Hip Thrust", "strength", "legs", "Barbell across the hips; peak-contraction glute work."),
    # --- Shoulders -----------------------------------------------------
    ("Overhead Press", "strength", "shoulders", "Standing barbell press from the front rack."),
    ("Dumbbell Shoulder Press", "strength", "shoulders", "Seated or standing press with independent arms."),
    ("Lateral Raise", "strength", "shoulders", "Isolation raise for the side delts."),
    ("Rear Delt Fly", "strength", "shoulders", "Bent-over reverse fly for the posterior delts."),
    # --- Arms ----------------------------------------------------------
    ("Barbell Curl", "strength", "arms", "Standing biceps curl with a straight or EZ bar."),
    ("Hammer Curl", "strength", "arms", "Neutral-grip curl hitting the brachialis and forearms."),
    ("Triceps Rope Pushdown", "strength", "arms", "Cable pushdown isolating the triceps."),
    ("Skull Crusher", "strength", "arms", "Lying triceps extension to the forehead."),
    ("Close-Grip Bench Press", "strength", "arms", "Narrow-grip press biasing the triceps."),
    # --- Core ----------------------------------------------------------
    ("Plank", "strength", "core", "Isometric front-brace hold; measured in seconds."),
    ("Hanging Leg Raise", "strength", "core", "Raise straight legs from a bar hang."),
    ("Cable Crunch", "strength", "core", "Kneeling weighted spinal flexion."),
    ("Russian Twist", "strength", "core", "Seated rotation for the obliques."),
    ("Dead Bug", "strength", "core", "Supine anti-extension drill with opposite limbs."),
    # --- Cardio --------------------------------------------------------
    ("Treadmill Run", "cardio", "full_body", "Steady-state or interval running; log reps as minutes."),
    ("Outdoor Run", "cardio", "full_body", "Road or trail running; log reps as minutes."),
    ("Cycling", "cardio", "legs", "Stationary or road cycling; log reps as minutes."),
    ("Rowing Machine", "cardio", "full_body", "Concept2-style erg; full-body conditioning."),
    ("Jump Rope", "cardio", "full_body", "Skipping intervals for calves and conditioning."),
    ("Stair Climber", "cardio", "legs", "Continuous stepping; low-impact leg conditioning."),
    ("Burpee", "cardio", "full_body", "Squat-thrust to jump; high-intensity conditioning."),
    ("Swimming", "cardio", "full_body", "Low-impact whole-body cardio; log reps as minutes."),
    # --- Flexibility / mobility ----------------------------------------
    ("Hamstring Stretch", "flexibility", "legs", "Static seated or standing hamstring hold."),
    ("Hip Flexor Stretch", "flexibility", "legs", "Half-kneeling stretch for the front of the hip."),
    ("Thoracic Rotation", "flexibility", "back", "Open-book rotation for mid-back mobility."),
    ("Shoulder Dislocate", "flexibility", "shoulders", "Banded or dowel pass-through for shoulder range."),
    ("Cat-Cow", "flexibility", "back", "Segmental spinal flexion and extension flow."),
    ("Couch Stretch", "flexibility", "legs", "Deep quad and hip flexor stretch against a wall."),
    ("Downward Dog", "flexibility", "full_body", "Yoga posture stretching calves, hamstrings, shoulders."),
    ("Pigeon Pose", "flexibility", "legs", "Hip external rotation and glute stretch."),
]


def seed_exercises(db: Session) -> tuple[int, int]:
    """Insert missing exercises, refresh changed descriptions.

    Returns (inserted, updated).
    """
    existing = {ex.name: ex for ex in db.scalars(select(Exercise))}
    inserted = updated = 0

    for name, category, muscle_group, description in EXERCISES:
        current = existing.get(name)
        if current is None:
            db.add(
                Exercise(
                    name=name,
                    category=category,
                    muscle_group=muscle_group,
                    description=description,
                )
            )
            inserted += 1
        elif (
            current.description != description
            or current.category != category
            or current.muscle_group != muscle_group
        ):
            current.description = description
            current.category = category
            current.muscle_group = muscle_group
            updated += 1

    db.commit()
    return inserted, updated


def main() -> None:
    db = SessionLocal()
    try:
        inserted, updated = seed_exercises(db)
        total = db.query(Exercise).count()
        print(f"Seed complete: {inserted} inserted, {updated} updated, {total} total.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
