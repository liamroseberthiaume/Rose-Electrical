"""Password hashing and JWT creation/verification.

Two token types share one secret but carry a `type` claim, so a refresh token
can never be presented as an access token (a classic mix-up vulnerability).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timedelta, timezone

import bcrypt
import jwt

from app.config import settings

ACCESS = "access"
REFRESH = "refresh"

# bcrypt only reads the first 72 bytes of a password and (as of 5.0) raises on
# anything longer, so we cap it explicitly rather than letting it blow up.
MAX_PASSWORD_BYTES = 72


def hash_password(password: str) -> str:
    return bcrypt.hashpw(
        password.encode("utf-8")[:MAX_PASSWORD_BYTES], bcrypt.gensalt()
    ).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(
            password.encode("utf-8")[:MAX_PASSWORD_BYTES], hashed.encode("utf-8")
        )
    except ValueError:
        return False


def _create_token(subject: int, token_type: str, lifetime: timedelta) -> tuple[str, str, datetime]:
    """Returns (encoded_jwt, jti, expires_at)."""
    now = datetime.now(timezone.utc)
    expires_at = now + lifetime
    jti = uuid.uuid4().hex
    payload = {
        "sub": str(subject),
        "type": token_type,
        "jti": jti,
        "iat": int(now.timestamp()),
        "exp": int(expires_at.timestamp()),
    }
    token = jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)
    return token, jti, expires_at


def create_access_token(user_id: int) -> tuple[str, str, datetime]:
    return _create_token(user_id, ACCESS, timedelta(minutes=settings.access_token_minutes))


def create_refresh_token(user_id: int) -> tuple[str, str, datetime]:
    return _create_token(user_id, REFRESH, timedelta(days=settings.refresh_token_days))


def decode_token(token: str, expected_type: str) -> dict:
    """Decode and validate a JWT. Raises jwt.PyJWTError on any problem."""
    payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
    if payload.get("type") != expected_type:
        raise jwt.InvalidTokenError(f"expected a {expected_type} token")
    if "sub" not in payload or "jti" not in payload:
        raise jwt.InvalidTokenError("malformed token")
    return payload
