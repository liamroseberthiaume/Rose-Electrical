"""Shared FastAPI dependencies — chiefly 'who is making this request?'."""

from __future__ import annotations

import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import RevokedAccessToken, User
from app.security import ACCESS, decode_token

bearer_scheme = HTTPBearer(auto_error=False)

CREDENTIALS_ERROR = HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Could not validate credentials",
    headers={"WWW-Authenticate": "Bearer"},
)


def get_current_user(
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    db: Session = Depends(get_db),
) -> User:
    if credentials is None:
        raise CREDENTIALS_ERROR

    try:
        payload = decode_token(credentials.credentials, ACCESS)
    except jwt.PyJWTError:
        raise CREDENTIALS_ERROR

    # Was this specific token killed by a logout before it expired?
    revoked = db.scalar(
        select(RevokedAccessToken).where(RevokedAccessToken.jti == payload["jti"])
    )
    if revoked is not None:
        raise CREDENTIALS_ERROR

    user = db.get(User, int(payload["sub"]))
    if user is None:
        raise CREDENTIALS_ERROR
    return user
