"""Progress reports over completed workouts.

Scope is deliberately basic: counts and totals for a period, plus the same
totals broken down by exercise category and muscle group. Everything is
computed in SQL over the user's own rows.
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, Query
from sqlalchemy import Float, cast, func, select
from sqlalchemy.orm import Session, selectinload

from app.database import get_db
from app.deps import get_current_user
from app.models import Exercise, User, Workout, WorkoutExercise, WorkoutStatus
from app.schemas import CategoryCount, ReportSummary, WorkoutOut

router = APIRouter(prefix="/reports", tags=["reports"])

# sets * reps * weight, as a SQL expression so the DB does the arithmetic.
VOLUME = func.sum(
    WorkoutExercise.sets * WorkoutExercise.reps * cast(WorkoutExercise.weight, Float)
)


def _breakdown(db: Session, user_id: int, column, start, end) -> list[CategoryCount]:
    stmt = (
        select(
            column.label("label"),
            func.count(func.distinct(Workout.id)).label("workouts"),
            func.sum(WorkoutExercise.sets).label("sets"),
            func.sum(WorkoutExercise.sets * WorkoutExercise.reps).label("reps"),
            VOLUME.label("volume"),
        )
        .select_from(Workout)
        .join(WorkoutExercise, WorkoutExercise.workout_id == Workout.id)
        .join(Exercise, Exercise.id == WorkoutExercise.exercise_id)
        .where(Workout.user_id == user_id, Workout.status == WorkoutStatus.completed)
        .group_by(column)
        .order_by(VOLUME.desc())
    )
    if start is not None:
        stmt = stmt.where(Workout.completed_at >= start)
    if end is not None:
        stmt = stmt.where(Workout.completed_at <= end)

    return [
        CategoryCount(
            label=row.label,
            workouts=row.workouts or 0,
            sets=row.sets or 0,
            reps=row.reps or 0,
            volume=round(row.volume or 0.0, 2),
        )
        for row in db.execute(stmt)
    ]


@router.get("/summary", response_model=ReportSummary)
def summary(
    days: int | None = Query(
        default=None, ge=1, le=3650, description="shorthand for the last N days"
    ),
    start: datetime | None = Query(default=None),
    end: datetime | None = Query(default=None),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Totals for completed workouts in a period.

    Pass `days=30` for a rolling window, or an explicit `start`/`end` pair.
    With no parameters it covers all time.
    """
    if days is not None and start is None:
        start = datetime.now(timezone.utc) - timedelta(days=days)

    def scoped(stmt):
        stmt = stmt.where(Workout.user_id == current_user.id)
        if start is not None:
            stmt = stmt.where(Workout.completed_at >= start)
        if end is not None:
            stmt = stmt.where(Workout.completed_at <= end)
        return stmt

    # Status counts. Pending/skipped have no completed_at, so the date window
    # only makes sense for completed ones — the others are lifetime counts.
    status_counts = dict(
        db.execute(
            select(Workout.status, func.count())
            .where(Workout.user_id == current_user.id)
            .group_by(Workout.status)
        ).all()
    )

    completed_in_window = db.scalar(
        scoped(select(func.count()).select_from(Workout)).where(
            Workout.status == WorkoutStatus.completed
        )
    )

    totals = db.execute(
        scoped(
            select(
                func.sum(WorkoutExercise.sets),
                func.sum(WorkoutExercise.sets * WorkoutExercise.reps),
                VOLUME,
                func.count(func.distinct(WorkoutExercise.exercise_id)),
            )
            .select_from(Workout)
            .join(WorkoutExercise, WorkoutExercise.workout_id == Workout.id)
            .where(Workout.status == WorkoutStatus.completed)
        )
    ).one()

    return ReportSummary(
        period_start=start,
        period_end=end,
        workouts_completed=completed_in_window or 0,
        workouts_pending=status_counts.get(WorkoutStatus.pending, 0),
        workouts_skipped=status_counts.get(WorkoutStatus.skipped, 0),
        total_sets=totals[0] or 0,
        total_reps=totals[1] or 0,
        total_volume=round(totals[2] or 0.0, 2),
        distinct_exercises=totals[3] or 0,
        by_category=_breakdown(db, current_user.id, Exercise.category, start, end),
        by_muscle_group=_breakdown(db, current_user.id, Exercise.muscle_group, start, end),
    )


@router.get("/history", response_model=list[WorkoutOut])
def history(
    limit: int = Query(default=25, ge=1, le=200),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Past (completed) workouts, most recent first."""
    stmt = (
        select(Workout)
        .options(selectinload(Workout.entries).joinedload(WorkoutExercise.exercise))
        .where(
            Workout.user_id == current_user.id,
            Workout.status == WorkoutStatus.completed,
        )
        .order_by(Workout.completed_at.desc(), Workout.id.desc())
        .limit(limit)
        .offset(offset)
    )
    return list(db.scalars(stmt).unique())
