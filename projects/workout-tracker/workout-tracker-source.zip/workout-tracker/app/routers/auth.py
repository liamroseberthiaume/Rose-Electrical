"""Sign-up, login, token refresh, logout.

Token model:
  * access token  — short lived (15 min), sent on every request
  * refresh token — long lived (7 days), stored in the DB, single use

Refresh tokens are *rotated*: using one revokes it and issues a new pair. If an
already-used refresh token turns up again, that means it leaked, so every token
for that user is revoked. Logout revokes the refresh token and denylists the
access token so it stops working immediately instead of lingering for 15 min.
"""

from __future__ import annotations

from datetime import datetime, timezone

import jwt
from fastapi import APIRouter, Body, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import or_, select
from sqlalchemy.orm import Session

from app.config import settings
from app.database import get_db
from app.deps import get_current_user
from app.models import RefreshToken, RevokedAccessToken, User
from app.ratelimit import RateLimiter
from app.schemas import RefreshRequest, TokenPair, UserCreate, UserLogin, UserOut
from app.security import (
    ACCESS,
    REFRESH,
    create_access_token,
    create_refresh_token,
    decode_token,
    hash_password,
    verify_password,
)

router = APIRouter(prefix="/auth", tags=["auth"])
bearer_scheme = HTTPBearer(auto_error=False)

# Public endpoints are the ones worth throttling: login is a password oracle
# and signup is a way to fill the database. Both are per-IP, per-endpoint.
login_limit = RateLimiter(times=8, seconds=60)
signup_limit = RateLimiter(times=5, seconds=3600)


def _issue_pair(db: Session, user: User) -> TokenPair:
    access, _, access_exp = create_access_token(user.id)
    refresh, refresh_jti, refresh_exp = create_refresh_token(user.id)

    db.add(RefreshToken(jti=refresh_jti, user_id=user.id, expires_at=refresh_exp))
    db.commit()

    return TokenPair(
        access_token=access,
        refresh_token=refresh,
        expires_in=settings.access_token_minutes * 60,
    )


@router.post(
    "/signup",
    response_model=UserOut,
    status_code=status.HTTP_201_CREATED,
    dependencies=[Depends(signup_limit)],
)
def signup(payload: UserCreate, db: Session = Depends(get_db)):
    clash = db.scalar(
        select(User).where(
            or_(User.email == payload.email.lower(), User.username == payload.username)
        )
    )
    if clash is not None:
        field = "email" if clash.email == payload.email.lower() else "username"
        raise HTTPException(status.HTTP_409_CONFLICT, f"That {field} is already registered")

    user = User(
        email=payload.email.lower(),
        username=payload.username,
        hashed_password=hash_password(payload.password),
    )
    db.add(user)
    db.commit()
    db.refresh(user)
    return user


@router.post("/login", response_model=TokenPair, dependencies=[Depends(login_limit)])
def login(payload: UserLogin, db: Session = Depends(get_db)):
    identifier = payload.identifier.strip()
    user = db.scalar(
        select(User).where(
            or_(User.email == identifier.lower(), User.username == identifier)
        )
    )
    # Same error and roughly the same work either way, so the response does not
    # reveal whether an account exists.
    if user is None or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Incorrect credentials")
    return _issue_pair(db, user)


@router.post("/refresh", response_model=TokenPair)
def refresh_tokens(payload: RefreshRequest, db: Session = Depends(get_db)):
    try:
        claims = decode_token(payload.refresh_token, REFRESH)
    except jwt.PyJWTError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")

    stored = db.scalar(select(RefreshToken).where(RefreshToken.jti == claims["jti"]))
    if stored is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")

    if not stored.is_active:
        # A revoked token being replayed means it was stolen. Burn them all.
        for token in db.scalars(
            select(RefreshToken).where(
                RefreshToken.user_id == stored.user_id, RefreshToken.revoked_at.is_(None)
            )
        ):
            token.revoked_at = datetime.now(timezone.utc)
        db.commit()
        raise HTTPException(
            status.HTTP_401_UNAUTHORIZED, "Refresh token reused — all sessions revoked"
        )

    stored.revoked_at = datetime.now(timezone.utc)  # rotate
    user = db.get(User, stored.user_id)
    if user is None:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid refresh token")
    return _issue_pair(db, user)


@router.post("/logout", status_code=status.HTTP_204_NO_CONTENT)
def logout(
    refresh_token: str | None = Body(default=None, embed=True),
    credentials: HTTPAuthorizationCredentials | None = Depends(bearer_scheme),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Kill this session. Pass the refresh token to revoke it too."""
    # 1. Denylist the access token that made this call.
    if credentials is not None:
        try:
            claims = decode_token(credentials.credentials, ACCESS)
            db.add(
                RevokedAccessToken(
                    jti=claims["jti"],
                    expires_at=datetime.fromtimestamp(claims["exp"], tz=timezone.utc),
                )
            )
        except jwt.PyJWTError:
            pass

    # 2. Revoke the matching refresh token, if supplied.
    if refresh_token:
        try:
            claims = decode_token(refresh_token, REFRESH)
            stored = db.scalar(
                select(RefreshToken).where(
                    RefreshToken.jti == claims["jti"],
                    RefreshToken.user_id == current_user.id,
                )
            )
            if stored is not None and stored.revoked_at is None:
                stored.revoked_at = datetime.now(timezone.utc)
        except jwt.PyJWTError:
            pass

    # Housekeeping: drop denylist rows whose tokens have expired anyway.
    now = datetime.now(timezone.utc)
    for dead in db.scalars(
        select(RevokedAccessToken).where(RevokedAccessToken.expires_at < now)
    ):
        db.delete(dead)

    db.commit()


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user
