"""Workout CRUD, scheduling, and listing.

Every query in here is filtered by `Workout.user_id == current_user.id`. That
is the entire authorisation story: a workout belonging to someone else is not
"forbidden", it simply does not exist as far as this user is concerned, which
is why the handlers return 404 rather than 403 — a 403 would confirm the row
exists and leak information.
"""

from __future__ import annotations

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.database import get_db
from app.deps import get_current_user
from app.models import Exercise, User, Workout, WorkoutExercise, WorkoutStatus
from app.schemas import WorkoutCreate, WorkoutExerciseIn, WorkoutOut, WorkoutUpdate

router = APIRouter(prefix="/workouts", tags=["workouts"])


def _owned_workout(workout_id: int, user: User, db: Session) -> Workout:
    workout = db.scalar(
        select(Workout)
        .options(selectinload(Workout.entries).joinedload(WorkoutExercise.exercise))
        .where(Workout.id == workout_id, Workout.user_id == user.id)
    )
    if workout is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Workout not found")
    return workout


def _build_entries(items: list[WorkoutExerciseIn], db: Session) -> list[WorkoutExercise]:
    """Validate exercise IDs once, then materialise the rows in order."""
    wanted = {item.exercise_id for item in items}
    found = set(db.scalars(select(Exercise.id).where(Exercise.id.in_(wanted))))
    missing = sorted(wanted - found)
    if missing:
        raise HTTPException(
            status.HTTP_422_UNPROCESSABLE_ENTITY, f"Unknown exercise id(s): {missing}"
        )
    return [
        WorkoutExercise(
            exercise_id=item.exercise_id,
            position=index,
            sets=item.sets,
            reps=item.reps,
            weight=item.weight,
            notes=item.notes,
        )
        for index, item in enumerate(items)
    ]


@router.post("", response_model=WorkoutOut, status_code=status.HTTP_201_CREATED)
def create_workout(
    payload: WorkoutCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    workout = Workout(
        user_id=current_user.id,
        name=payload.name,
        comment=payload.comment,
        scheduled_at=payload.scheduled_at,
        entries=_build_entries(payload.exercises, db),
    )
    db.add(workout)
    db.commit()
    db.refresh(workout)
    return workout


@router.get("", response_model=list[WorkoutOut])
def list_workouts(
    status_filter: WorkoutStatus | None = Query(
        default=None, alias="status", description="pending | completed | skipped"
    ),
    upcoming: bool = Query(
        default=False, description="only pending workouts scheduled from now on"
    ),
    date_from: datetime | None = Query(default=None),
    date_to: datetime | None = Query(default=None),
    order: str = Query(default="asc", pattern="^(asc|desc)$"),
    limit: int = Query(default=100, ge=1, le=500),
    offset: int = Query(default=0, ge=0),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Active/pending workouts sorted by scheduled date and time.

    Default (no filters) returns everything oldest-first. `upcoming=true` gives
    the 'what's next' view the dashboard uses.
    """
    stmt = (
        select(Workout)
        .options(selectinload(Workout.entries).joinedload(WorkoutExercise.exercise))
        .where(Workout.user_id == current_user.id)
    )

    if upcoming:
        stmt = stmt.where(
            Workout.status == WorkoutStatus.pending,
            Workout.scheduled_at.is_not(None),
            Workout.scheduled_at >= datetime.now(timezone.utc),
        )
    elif status_filter is not None:
        stmt = stmt.where(Workout.status == status_filter)

    if date_from is not None:
        stmt = stmt.where(Workout.scheduled_at >= date_from)
    if date_to is not None:
        stmt = stmt.where(Workout.scheduled_at <= date_to)

    # Unscheduled workouts sort last in ascending order rather than first.
    sort_key = Workout.scheduled_at
    stmt = stmt.order_by(
        sort_key.is_(None),
        sort_key.asc() if order == "asc" else sort_key.desc(),
        Workout.id.asc(),
    )
    return list(db.scalars(stmt.limit(limit).offset(offset)).unique())


@router.get("/{workout_id}", response_model=WorkoutOut)
def get_workout(
    workout_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    return _owned_workout(workout_id, current_user, db)


@router.patch("/{workout_id}", response_model=WorkoutOut)
def update_workout(
    workout_id: int,
    payload: WorkoutUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Partial update. Supplying `exercises` replaces the whole exercise list."""
    workout = _owned_workout(workout_id, current_user, db)
    data = payload.model_dump(exclude_unset=True)

    if "exercises" in data:
        items = payload.exercises or []
        if not items:
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY, "A workout needs at least one exercise"
            )
        ids = [item.exercise_id for item in items]
        if len(ids) != len(set(ids)):
            raise HTTPException(
                status.HTTP_422_UNPROCESSABLE_ENTITY,
                "The same exercise cannot be added twice to one workout",
            )
        workout.entries = _build_entries(items, db)
        data.pop("exercises")

    if "status" in data and data["status"] is not None:
        new_status = WorkoutStatus(data.pop("status"))
        workout.status = new_status
        workout.completed_at = (
            datetime.now(timezone.utc) if new_status is WorkoutStatus.completed else None
        )

    for field, value in data.items():
        setattr(workout, field, value)

    db.commit()
    db.refresh(workout)
    return workout


@router.post("/{workout_id}/complete", response_model=WorkoutOut)
def complete_workout(
    workout_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Convenience endpoint — marks a workout done so it lands in reports."""
    workout = _owned_workout(workout_id, current_user, db)
    workout.status = WorkoutStatus.completed
    workout.completed_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(workout)
    return workout


@router.delete("/{workout_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_workout(
    workout_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    workout = _owned_workout(workout_id, current_user, db)
    db.delete(workout)  # cascade removes the workout_exercises rows
    db.commit()
