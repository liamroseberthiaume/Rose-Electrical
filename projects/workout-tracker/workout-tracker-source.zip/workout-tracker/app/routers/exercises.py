"""Read-only exercise catalogue. Auth required, but shared across all users."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.database import get_db
from app.deps import get_current_user
from app.models import Exercise, User
from app.schemas import ExerciseOut

router = APIRouter(prefix="/exercises", tags=["exercises"])


@router.get("", response_model=list[ExerciseOut])
def list_exercises(
    category: str | None = Query(default=None, description="strength | cardio | flexibility"),
    muscle_group: str | None = Query(default=None),
    search: str | None = Query(default=None, description="case-insensitive name match"),
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    stmt = select(Exercise)
    if category:
        stmt = stmt.where(Exercise.category == category.lower())
    if muscle_group:
        stmt = stmt.where(Exercise.muscle_group == muscle_group.lower())
    if search:
        stmt = stmt.where(Exercise.name.ilike(f"%{search}%"))
    return list(db.scalars(stmt.order_by(Exercise.muscle_group, Exercise.name)))


@router.get("/{exercise_id}", response_model=ExerciseOut)
def get_exercise(
    exercise_id: int,
    db: Session = Depends(get_db),
    _: User = Depends(get_current_user),
):
    exercise = db.get(Exercise, exercise_id)
    if exercise is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Exercise not found")
    return exercise
