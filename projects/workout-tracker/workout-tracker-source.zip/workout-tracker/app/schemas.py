"""Pydantic request/response models — the API contract."""

from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, ConfigDict, EmailStr, Field, field_validator

from app.models import WorkoutStatus


# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------
class UserCreate(BaseModel):
    email: EmailStr
    username: str = Field(min_length=3, max_length=50, pattern=r"^[A-Za-z0-9_.-]+$")
    password: str = Field(min_length=8, max_length=72)


class UserLogin(BaseModel):
    # Accepts either the email or the username in the same field.
    identifier: str
    password: str


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    email: EmailStr
    username: str
    created_at: datetime


class TokenPair(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int  # seconds until the access token expires


class RefreshRequest(BaseModel):
    refresh_token: str


# ---------------------------------------------------------------------------
# Exercises
# ---------------------------------------------------------------------------
class ExerciseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    description: str
    category: str
    muscle_group: str


# ---------------------------------------------------------------------------
# Workouts
# ---------------------------------------------------------------------------
class WorkoutExerciseIn(BaseModel):
    exercise_id: int
    sets: int = Field(gt=0, le=100)
    reps: int = Field(gt=0, le=1000)
    weight: float = Field(default=0.0, ge=0, le=1000)
    notes: str | None = Field(default=None, max_length=500)


class WorkoutExerciseOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    exercise_id: int
    position: int
    sets: int
    reps: int
    weight: float
    notes: str | None
    exercise: ExerciseOut
    volume: float


class WorkoutCreate(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    comment: str | None = Field(default=None, max_length=2000)
    scheduled_at: datetime | None = None
    exercises: list[WorkoutExerciseIn] = Field(min_length=1)

    @field_validator("exercises")
    @classmethod
    def no_duplicate_exercises(cls, v: list[WorkoutExerciseIn]) -> list[WorkoutExerciseIn]:
        ids = [e.exercise_id for e in v]
        if len(ids) != len(set(ids)):
            raise ValueError("the same exercise cannot be added twice to one workout")
        return v


class WorkoutUpdate(BaseModel):
    """All fields optional — a PATCH. Sending `exercises` replaces the whole list."""

    name: str | None = Field(default=None, min_length=1, max_length=120)
    comment: str | None = Field(default=None, max_length=2000)
    scheduled_at: datetime | None = None
    status: WorkoutStatus | None = None
    exercises: list[WorkoutExerciseIn] | None = None


class WorkoutOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    comment: str | None
    scheduled_at: datetime | None
    status: WorkoutStatus
    completed_at: datetime | None
    created_at: datetime
    updated_at: datetime
    entries: list[WorkoutExerciseOut]
    total_volume: float


# ---------------------------------------------------------------------------
# Reports
# ---------------------------------------------------------------------------
class CategoryCount(BaseModel):
    label: str
    workouts: int
    sets: int
    reps: int
    volume: float


class ReportSummary(BaseModel):
    period_start: datetime | None
    period_end: datetime | None
    workouts_completed: int
    workouts_pending: int
    workouts_skipped: int
    total_sets: int
    total_reps: int
    total_volume: float
    distinct_exercises: int
    by_category: list[CategoryCount]
    by_muscle_group: list[CategoryCount]
