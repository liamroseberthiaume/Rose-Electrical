"""Application configuration.

Everything is read from environment variables so the same code runs in dev and
prod. See .env.example for the full list.
"""

import os
from functools import lru_cache


class Settings:
    # --- Database -------------------------------------------------------
    # SQLite by default; swap this one URL for postgresql+psycopg://... later.
    database_url: str = os.getenv("DATABASE_URL", "sqlite:///./workout_tracker.db")

    # --- Auth -----------------------------------------------------------
    # CHANGE THIS IN PRODUCTION. Generate with: openssl rand -hex 32
    jwt_secret: str = os.getenv("JWT_SECRET", "dev-secret-change-me")
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = int(os.getenv("ACCESS_TOKEN_MINUTES", "15"))
    refresh_token_days: int = int(os.getenv("REFRESH_TOKEN_DAYS", "7"))

    # --- App ------------------------------------------------------------
    app_name: str = "Workout Tracker API"
    api_prefix: str = "/api"

    # Origins allowed to call this API from a browser. Comma-separated, e.g.
    #   CORS_ORIGINS=https://roseelectrical.com,https://www.roseelectrical.com
    # The bundled frontend is same-origin and needs no entry here; this is for
    # a separately-hosted UI (a portfolio site calling a deployed API).
    cors_origins: list[str] = [
        o.strip()
        for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",")
        if o.strip()
    ]

    # Throttle the public auth endpoints. Turn off for test runs, which log in
    # far more often than a human would:  RATE_LIMIT_ENABLED=false
    rate_limit_enabled: bool = os.getenv("RATE_LIMIT_ENABLED", "true").lower() not in {
        "false", "0", "no"
    }


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
