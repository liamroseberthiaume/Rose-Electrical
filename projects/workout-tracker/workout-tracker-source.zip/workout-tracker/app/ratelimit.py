"""A small in-process rate limiter for the auth endpoints.

Once the API is on the public internet, `/auth/login` is a password-guessing
oracle and `/auth/signup` is a way to fill the database. This caps both.

It is deliberately dependency-free and in-memory, which means it resets on
restart and counts per worker process. That is fine for a single-instance
deployment; if you scale to several workers or dynos, move the counter to
Redis (the interface below is small enough that swapping the backing store
touches one function).
"""

from __future__ import annotations

import time
from collections import defaultdict, deque

from fastapi import HTTPException, Request, status

from app.config import settings

# path -> (max requests, window in seconds)
_buckets: dict[str, deque] = defaultdict(deque)


def client_ip(request: Request) -> str:
    """Best-effort client address.

    Platforms like Railway, Render and Fly terminate TLS at a proxy, so the
    socket address is the proxy's. The real client is the first entry in
    X-Forwarded-For. Only trust that header when you know a proxy is in front
    of you — otherwise a caller can simply set it and dodge the limit.
    """
    forwarded = request.headers.get("x-forwarded-for")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


class RateLimiter:
    """FastAPI dependency: `Depends(RateLimiter(times=5, seconds=60))`."""

    def __init__(self, times: int, seconds: int):
        self.times = times
        self.seconds = seconds

    async def __call__(self, request: Request) -> None:
        if not settings.rate_limit_enabled:
            return

        key = f"{request.url.path}:{client_ip(request)}"
        now = time.monotonic()
        hits = _buckets[key]

        while hits and now - hits[0] > self.seconds:
            hits.popleft()

        if len(hits) >= self.times:
            retry_after = int(self.seconds - (now - hits[0])) + 1
            raise HTTPException(
                status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Too many attempts. Try again shortly.",
                headers={"Retry-After": str(retry_after)},
            )

        hits.append(now)

        # Opportunistic cleanup so abandoned keys do not accumulate forever.
        if len(_buckets) > 10_000:
            for k in [k for k, v in _buckets.items() if not v or now - v[-1] > self.seconds]:
                _buckets.pop(k, None)
