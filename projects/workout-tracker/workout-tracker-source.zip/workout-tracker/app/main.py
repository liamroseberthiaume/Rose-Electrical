"""FastAPI application entry point.

Run with:  uvicorn app.main:app --reload
Then open: http://127.0.0.1:8000       (frontend)
           http://127.0.0.1:8000/docs  (interactive API docs)
"""

from __future__ import annotations

from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import SessionLocal, engine
from app.models import Base, Exercise
from app.routers import auth, exercises, reports, workouts
from app.seed import seed_exercises

STATIC_DIR = Path(__file__).resolve().parent.parent / "static"


@asynccontextmanager
async def lifespan(_app: FastAPI):
    # Alembic owns the schema in a real deployment; create_all is a safety net
    # so a fresh clone runs without any migration step.
    Base.metadata.create_all(bind=engine)

    db = SessionLocal()
    try:
        if db.query(Exercise).count() == 0:
            inserted, _ = seed_exercises(db)
            print(f"[startup] Seeded {inserted} exercises.")
    finally:
        db.close()

    yield


app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    description=(
        "Backend for a workout tracker: JWT auth with refresh tokens, an exercise "
        "catalogue, workout plans with scheduling, and progress reports."
    ),
    lifespan=lifespan,
)

# The bundled frontend is served from the same origin, so CORS is only needed
# if you point a separately-hosted UI at this API. Set CORS_ORIGINS to the
# exact origins that should be allowed — never "*" on an API that takes
# credentials.
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

for router in (auth.router, exercises.router, workouts.router, reports.router):
    app.include_router(router, prefix=settings.api_prefix)


@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok"}


@app.get("/", include_in_schema=False)
def index():
    return FileResponse(STATIC_DIR / "index.html")


app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")
