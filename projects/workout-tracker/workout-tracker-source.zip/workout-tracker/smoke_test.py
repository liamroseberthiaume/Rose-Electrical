"""End-to-end smoke test against a running server.

    RATE_LIMIT_ENABLED=false uvicorn app.main:app --port 8000 &
    python smoke_test.py

Point it at a deployment with BASE=https://your-app.example.com/api.

Exercises every endpoint, then checks the two things most likely to be quietly
broken: that one user cannot touch another user's data, and that the report
totals match hand-computed volume.

The auth throttle in app/ratelimit.py counts logins per IP, and this suite logs
in far more often than a person would — run the server with
RATE_LIMIT_ENABLED=false, or expect 429s near the end.
"""

from __future__ import annotations

import os
import sys
import uuid
from datetime import datetime, timedelta, timezone

import httpx

BASE = os.getenv("BASE", "http://127.0.0.1:8000/api").rstrip("/")
passed = failed = 0


def check(label: str, condition: bool, detail: str = "") -> None:
    global passed, failed
    if condition:
        passed += 1
        print(f"  PASS  {label}")
    else:
        failed += 1
        print(f"  FAIL  {label} {detail}")


def auth(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def main() -> int:
    c = httpx.Client(timeout=15)
    tag = uuid.uuid4().hex[:8]

    print("\n== Health ==")
    r = c.get(f"{BASE}/health")
    check("health returns ok", r.status_code == 200 and r.json()["status"] == "ok")

    print("\n== Sign-up & login ==")
    creds = {"email": f"alice_{tag}@example.com", "username": f"alice_{tag}", "password": "correct-horse-1"}
    r = c.post(f"{BASE}/auth/signup", json=creds)
    check("signup 201", r.status_code == 201, r.text)

    r = c.post(f"{BASE}/auth/signup", json=creds)
    check("duplicate signup rejected 409", r.status_code == 409, r.text)

    r = c.post(f"{BASE}/auth/signup", json={**creds, "email": f"x_{tag}@e.com", "username": f"x{tag}", "password": "short"})
    check("weak password rejected 422", r.status_code == 422)

    r = c.post(f"{BASE}/auth/login", json={"identifier": creds["email"], "password": "wrong"})
    check("bad password rejected 401", r.status_code == 401)

    r = c.post(f"{BASE}/auth/login", json={"identifier": creds["username"], "password": creds["password"]})
    check("login by username 200", r.status_code == 200, r.text)
    tokens = r.json()
    access, refresh = tokens["access_token"], tokens["refresh_token"]

    r = c.get(f"{BASE}/auth/me", headers=auth(access))
    check("me returns the right user", r.status_code == 200 and r.json()["username"] == creds["username"])

    print("\n== Auth enforcement ==")
    check("no token -> 401", c.get(f"{BASE}/workouts").status_code == 401)
    check("garbage token -> 401", c.get(f"{BASE}/workouts", headers=auth("not.a.jwt")).status_code == 401)
    check("refresh token rejected as access token",
          c.get(f"{BASE}/workouts", headers=auth(refresh)).status_code == 401)

    print("\n== Exercise catalogue ==")
    r = c.get(f"{BASE}/exercises", headers=auth(access))
    catalog = r.json()
    check("catalogue seeded", r.status_code == 200 and len(catalog) >= 40, f"got {len(catalog)}")
    cats = {e["category"] for e in catalog}
    check("all three categories present", {"strength", "cardio", "flexibility"} <= cats, str(cats))
    r = c.get(f"{BASE}/exercises?muscle_group=chest", headers=auth(access))
    check("muscle_group filter works",
          r.status_code == 200 and all(e["muscle_group"] == "chest" for e in r.json()) and r.json())

    bench = next(e for e in catalog if e["name"] == "Barbell Bench Press")
    row = next(e for e in catalog if e["name"] == "Barbell Row")
    squat = next(e for e in catalog if e["name"] == "Back Squat")

    print("\n== Workout CRUD ==")
    tomorrow = (datetime.now(timezone.utc) + timedelta(days=1)).isoformat()
    payload = {
        "name": "Push day A",
        "comment": "First session.",
        "scheduled_at": tomorrow,
        "exercises": [
            {"exercise_id": bench["id"], "sets": 4, "reps": 8, "weight": 60},
            {"exercise_id": row["id"], "sets": 3, "reps": 10, "weight": 40},
        ],
    }
    r = c.post(f"{BASE}/workouts", json=payload, headers=auth(access))
    check("create workout 201", r.status_code == 201, r.text)
    workout = r.json()
    expected_volume = 4 * 8 * 60 + 3 * 10 * 40  # 1920 + 1200 = 3120
    check("total_volume computed correctly",
          workout["total_volume"] == expected_volume, f"{workout['total_volume']} != {expected_volume}")
    check("entries keep their order",
          [e["exercise_id"] for e in workout["entries"]] == [bench["id"], row["id"]])
    check("scheduled_at round-trips as UTC", workout["scheduled_at"] is not None)

    r = c.post(f"{BASE}/workouts", json={**payload, "exercises": [
        {"exercise_id": bench["id"], "sets": 3, "reps": 5, "weight": 50},
        {"exercise_id": bench["id"], "sets": 3, "reps": 5, "weight": 50}]}, headers=auth(access))
    check("duplicate exercise rejected 422", r.status_code == 422, r.text)

    r = c.post(f"{BASE}/workouts", json={**payload, "exercises": [
        {"exercise_id": 999999, "sets": 3, "reps": 5, "weight": 50}]}, headers=auth(access))
    check("unknown exercise id rejected 422", r.status_code == 422, r.text)

    r = c.post(f"{BASE}/workouts", json={**payload, "exercises": [
        {"exercise_id": bench["id"], "sets": 0, "reps": 5, "weight": 50}]}, headers=auth(access))
    check("zero sets rejected 422", r.status_code == 422)

    r = c.patch(f"{BASE}/workouts/{workout['id']}",
                json={"comment": "Updated note.", "name": "Push day A (v2)"}, headers=auth(access))
    check("patch updates fields",
          r.status_code == 200 and r.json()["comment"] == "Updated note."
          and r.json()["name"] == "Push day A (v2)", r.text)
    check("patch leaves exercises alone", len(r.json()["entries"]) == 2)

    r = c.patch(f"{BASE}/workouts/{workout['id']}",
                json={"exercises": [{"exercise_id": squat["id"], "sets": 5, "reps": 5, "weight": 100}]},
                headers=auth(access))
    check("patch replaces the exercise list",
          r.status_code == 200 and len(r.json()["entries"]) == 1
          and r.json()["total_volume"] == 2500, r.text)

    print("\n== Scheduling & listing ==")
    yesterday = (datetime.now(timezone.utc) - timedelta(days=1)).isoformat()
    past = c.post(f"{BASE}/workouts", json={
        "name": "Leg day (past)", "scheduled_at": yesterday,
        "exercises": [{"exercise_id": squat["id"], "sets": 5, "reps": 5, "weight": 80}]},
        headers=auth(access)).json()

    r = c.get(f"{BASE}/workouts?upcoming=true", headers=auth(access))
    ids = [w["id"] for w in r.json()]
    check("upcoming includes the future workout", workout["id"] in ids)
    check("upcoming excludes the past workout", past["id"] not in ids)

    r = c.get(f"{BASE}/workouts?order=asc", headers=auth(access))
    dates = [w["scheduled_at"] for w in r.json() if w["scheduled_at"]]
    check("list sorted ascending by schedule", dates == sorted(dates), str(dates))

    r = c.get(f"{BASE}/workouts?status=pending", headers=auth(access))
    check("status filter works", all(w["status"] == "pending" for w in r.json()) and r.json())

    print("\n== Ownership isolation ==")
    bob = {"email": f"bob_{tag}@example.com", "username": f"bob_{tag}", "password": "another-pass-99"}
    c.post(f"{BASE}/auth/signup", json=bob)
    bob_access = c.post(f"{BASE}/auth/login",
                        json={"identifier": bob["email"], "password": bob["password"]}).json()["access_token"]

    check("bob cannot read alice's workout",
          c.get(f"{BASE}/workouts/{workout['id']}", headers=auth(bob_access)).status_code == 404)
    check("bob cannot patch alice's workout",
          c.patch(f"{BASE}/workouts/{workout['id']}", json={"name": "hacked"},
                  headers=auth(bob_access)).status_code == 404)
    check("bob cannot delete alice's workout",
          c.delete(f"{BASE}/workouts/{workout['id']}", headers=auth(bob_access)).status_code == 404)
    check("bob's list is empty", c.get(f"{BASE}/workouts", headers=auth(bob_access)).json() == [])
    check("alice's workout survived",
          c.get(f"{BASE}/workouts/{workout['id']}", headers=auth(access)).json()["name"] == "Push day A (v2)")

    print("\n== Reports ==")
    c.post(f"{BASE}/workouts/{workout['id']}/complete", headers=auth(access))
    c.post(f"{BASE}/workouts/{past['id']}/complete", headers=auth(access))

    r = c.get(f"{BASE}/reports/summary", headers=auth(access))
    summary = r.json()
    # workout is now 5x5x100 = 2500 (squat), past is 5x5x80 = 2000 (squat)
    check("summary counts completed workouts", summary["workouts_completed"] == 2, str(summary))
    check("summary total volume correct", summary["total_volume"] == 4500.0, str(summary["total_volume"]))
    check("summary total sets correct", summary["total_sets"] == 10, str(summary["total_sets"]))
    check("summary total reps correct", summary["total_reps"] == 50, str(summary["total_reps"]))
    check("distinct exercises correct", summary["distinct_exercises"] == 1, str(summary["distinct_exercises"]))

    legs = next((b for b in summary["by_muscle_group"] if b["label"] == "legs"), None)
    check("muscle-group breakdown adds up", legs is not None and legs["volume"] == 4500.0, str(legs))
    check("category breakdown adds up",
          sum(b["volume"] for b in summary["by_category"]) == 4500.0, str(summary["by_category"]))

    r = c.get(f"{BASE}/reports/summary?days=1", headers=auth(access))
    check("days window narrows results", r.json()["workouts_completed"] == 2, r.text)

    r = c.get(f"{BASE}/reports/history", headers=auth(access))
    check("history returns completed only",
          r.status_code == 200 and len(r.json()) == 2
          and all(w["status"] == "completed" for w in r.json()), r.text)

    check("bob's report is all zeros",
          c.get(f"{BASE}/reports/summary", headers=auth(bob_access)).json()["total_volume"] == 0.0)

    print("\n== Refresh rotation & logout ==")
    r = c.post(f"{BASE}/auth/refresh", json={"refresh_token": refresh})
    check("refresh issues a new pair", r.status_code == 200, r.text)
    new_tokens = r.json()
    check("new access token works",
          c.get(f"{BASE}/auth/me", headers=auth(new_tokens["access_token"])).status_code == 200)
    check("old refresh token is now dead",
          c.post(f"{BASE}/auth/refresh", json={"refresh_token": refresh}).status_code == 401)

    # That replay just triggered the reuse defence, which revokes everything.
    r = c.post(f"{BASE}/auth/login", json={"identifier": creds["email"], "password": creds["password"]})
    fresh = r.json()
    r = c.post(f"{BASE}/auth/logout", json={"refresh_token": fresh["refresh_token"]},
               headers=auth(fresh["access_token"]))
    check("logout 204", r.status_code == 204, r.text)
    check("access token denylisted after logout",
          c.get(f"{BASE}/auth/me", headers=auth(fresh["access_token"])).status_code == 401)
    check("refresh token revoked after logout",
          c.post(f"{BASE}/auth/refresh", json={"refresh_token": fresh["refresh_token"]}).status_code == 401)

    print("\n== Delete ==")
    login2 = c.post(f"{BASE}/auth/login",
                    json={"identifier": creds["email"], "password": creds["password"]}).json()
    a2 = login2["access_token"]
    check("delete 204", c.delete(f"{BASE}/workouts/{past['id']}", headers=auth(a2)).status_code == 204)
    check("deleted workout is gone",
          c.get(f"{BASE}/workouts/{past['id']}", headers=auth(a2)).status_code == 404)

    print(f"\n{'=' * 46}\n  {passed} passed, {failed} failed\n{'=' * 46}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
