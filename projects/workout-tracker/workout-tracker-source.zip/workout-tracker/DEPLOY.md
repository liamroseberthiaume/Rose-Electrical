# Deploying the API

The demo on the portfolio site runs entirely in the browser. This is how you
put the *real* service on the internet so that page can talk to it.

Any host that runs a Python process works — Railway, Render, Fly.io, or a VPS.
The instructions below use Railway because its free tier includes a Postgres
instance, but nothing here is Railway-specific.

---

## 1. Get it into Git

```bash
cd workout-tracker
git init
git add .
git commit -m "Workout tracker API"
gh repo create workout-tracker --public --source=. --push
```

`.gitignore` already excludes `.env` and `*.db`, so your secret and your local
database stay out of the repo. Check that before the first push — a JWT secret
in Git history is a secret you have to rotate.

## 2. Add a start command

Hosts need to know how to run it. Create `Procfile` in the project root:

```
web: alembic upgrade head && uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Running the migration on boot means a fresh deploy builds its own schema. The
`$PORT` variable is assigned by the platform — hardcoding 8000 is the single
most common reason a first deploy comes up unreachable.

## 3. Switch to Postgres

SQLite writes to local disk, and most platforms give containers an ephemeral
filesystem — every redeploy would wipe your data. Add a Postgres instance
(on Railway: *New → Database → PostgreSQL*), then add the driver:

```bash
echo "psycopg[binary]>=3.2" >> requirements.txt
```

No code changes. `DATABASE_URL` is already the only place the database is
named, and the `UTCDateTime` type and Alembic migrations both work unmodified —
though Postgres, unlike SQLite, would have handled timezones correctly on its
own.

## 4. Set the environment variables

| Variable | Value |
| --- | --- |
| `DATABASE_URL` | `postgresql+psycopg://...` — most platforms inject this; make sure the scheme has `+psycopg` |
| `JWT_SECRET` | `python -c "import secrets; print(secrets.token_hex(32))"` |
| `CORS_ORIGINS` | the exact origin of your site, e.g. `https://roseelectrical.com` |
| `ACCESS_TOKEN_MINUTES` | `15` |
| `REFRESH_TOKEN_DAYS` | `7` |

`CORS_ORIGINS` is what lets the browser on your portfolio site call an API on a
different domain. List exact origins — scheme, host and port must match, and no
trailing slash. Never use `*` here: this API accepts credentials, and browsers
refuse that combination anyway.

## 5. Point the demo page at it

In `workout_tracker_demo.html`:

```js
const DEMO_MODE = false;
const API_BASE  = 'https://your-app.up.railway.app/api';
```

Every call already goes through one `api()` function, so those two lines are
the entire switch. Worth keeping a copy with `DEMO_MODE = true` — free tiers
sleep after inactivity, and a sandbox that always works beats a live API that
takes 30 seconds to wake up.

## 6. Check it

```bash
curl https://your-app.up.railway.app/api/health
```

Then run the full suite against the deployed instance:

```bash
BASE=https://your-app.up.railway.app/api python smoke_test.py
```

(Point `BASE` at the deployment first — the file currently hardcodes
localhost.) Expect the rate-limit tests to be the ones that fail if you run it
repeatedly; that is the limiter working.

---

## Before you call it public

**Rotate the secret if it ever leaked.** Every existing token is signed with
it; changing `JWT_SECRET` invalidates all of them, which is exactly what you
want after an exposure.

**The rate limiter is in-process.** `app/ratelimit.py` counts in memory, so it
resets on restart and counts per worker. Fine for one instance. If you scale to
several, move the counter to Redis — the interface is one function wide.

**Anyone can sign up.** That is the point of a demo, but it also means your
database grows with strangers' accounts. Options, roughly in order of effort:
seed a shared `demo / demo` account and mention it on the page; add a nightly
job that deletes accounts older than 7 days; or require an invite code via an
environment variable.

**Watch the free tier's disk and row limits.** A workout tracker's rows are
tiny, but a public signup form plus no cleanup will find the ceiling eventually.
